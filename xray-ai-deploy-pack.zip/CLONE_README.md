# CS X-ray Assist — clinic clone pack

This is a trimmed copy of the local X-ray AI backend (`xray-ai-service`), meant
to be dropped onto another clinic's Windows PC so it gets the same trained
caries model and detection logic running locally at `http://127.0.0.1:8765`.

It deliberately does **not** include:

- The Python virtual environment or the pretrained third-party model cache
  (both are large and machine-specific — they get created/downloaded fresh on
  first run instead, see below).
- Training scripts/datasets/run artifacts (`caries/train/`, `caries/_model_backups/`).
- This clinic's patient feedback data (`caries/clinic_data/` — images, labels,
  manifest of clinician verdicts). That data is specific to this clinic's
  patients and consent, and should not travel with the code.

What **is** included: all backend code plus the one thing that's actually this
clinic's own trained asset — `xray-ai-service/caries/weights/best.pt` (the
caries segmentation model).

---

## 1. Read this before deploying to a live clinic

The service loads two third-party pretrained models in addition to your own
`best.pt`. One of them has a licence that matters:

- **Tooth/FDI detector** (`abychkov/dental-fdi-detection`) — **Proprietary,
  Non-Commercial licence**. It explicitly **prohibits clinical or diagnostic
  use, commercial use without a separate licence, and redistribution**.
  Permitted use is academic research, education, and internal technical
  validation only. Using it on real patients in a live clinic is outside that
  grant unless you've obtained a separate commercial/clinical licence from the
  author (contact in `xray-ai-service/README.md`).
  - If you don't have that licence, set `ENABLE_TOOTH_MODEL=false` as an
    environment variable before starting the service. You'll lose bone-loss
    measurement and the enamel/dentin split, but the caries model and the
    condition detector (Apache-2.0, no restriction) still work.
- The caries model (`best.pt`) is loaded through the **Ultralytics YOLO**
  runtime (it's a YOLOv8-seg checkpoint). Ultralytics' code is AGPL-3.0;
  closed/commercial deployments generally need an Ultralytics **Enterprise
  licence**. Worth confirming your status there too before wider rollout.
- **Do not** re-upload the pretrained `model_cache/` contents anywhere
  (GitHub, shared drives, etc.) — that would likely count as "redistribution"
  under the tooth detector's licence. Let each clinic PC download it directly
  from Hugging Face via `download_models.py` (see below), which is that
  model's own sanctioned distribution channel.

Full detail: `xray-ai-service/README.md`.

---

## 2. Install on the new clinic PC

Requirements: Windows, Python 3.10+ on PATH, internet access (for the
one-time dependency + model download — a few GB total, only needed once).

1. Copy this whole `xray-ai-deploy-pack` folder onto the target PC, anywhere
   you like (e.g. next to that clinic's copy of the clinic-manager web app).
2. Double-click `start-xray-ai.bat`.
   - First run: creates a Python virtual environment under
     `%LOCALAPPDATA%\cs-xray-ai\venv`, installs dependencies from
     `xray-ai-service\requirements.txt`, then downloads the two pretrained
     models into `%LOCALAPPDATA%\cs-xray-ai\model_cache`. This step needs a
     working internet connection and can take several minutes to download a
     few GB, one time only.
   - Later runs: skip straight to starting the service (fast).
3. Once it prints `Starting on http://127.0.0.1:8765`, open
   `http://127.0.0.1:8765/health` in a browser on that PC. You should see
   `"ok": true` and each of `tooth_detector` / `condition_detector` /
   `caries_model` reporting `"ready": true`. `caries_model.weights` should
   point at `...\xray-ai-service\caries\weights\best.pt`.
4. Leave that window open while clinic staff use the X-ray Assist feature —
   the clinic-manager web app talks to it automatically at
   `http://127.0.0.1:8765` (that's already the default in `app-xray-ai.js`;
   no web-app configuration changes are needed as long as the web app and
   this service run on the same PC).

### If the clinic PC has slow/limited internet

The one-time download in step 2 is the only part that needs bandwidth. To
avoid it entirely:

- Copy this machine's `%LOCALAPPDATA%\cs-xray-ai\model_cache` folder onto a
  USB drive and drop it into `%LOCALAPPDATA%\cs-xray-ai\model_cache` on the
  target PC *before* running `start-xray-ai.bat` (then create an empty file
  named `.downloaded` inside that folder so the script knows to skip the
  download step).
- For the Python dependencies, you can instead run, on a machine with good
  bandwidth:
  `pip download -r xray-ai-service\requirements.txt -d wheelhouse`
  then copy the `wheelhouse` folder to the clinic PC and install offline with:
  `python -m pip install --no-index --find-links=wheelhouse -r xray-ai-service\requirements.txt`

---

## 3. Updating the model later

If you retrain and want to push a better model to other clinics, you only
need to replace one small file:
`xray-ai-service\caries\weights\best.pt` (a few MB). Copy the new file over
the old one on each clinic PC and restart `start-xray-ai.bat` — no
reinstall needed.
