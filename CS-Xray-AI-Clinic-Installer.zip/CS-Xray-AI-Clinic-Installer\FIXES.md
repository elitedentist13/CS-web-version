# Clinic pack fixes (2026-08-13)

Integrated into this deploy pack / installer:

1. **Missing service folder** — pack always ships `xray-ai-service\` + `best.pt`.
2. **Broken / partial venv** — `start-xray-ai.bat` re-installs deps when
   `onnxruntime`, `transformers`, `torch`, `ultralytics`, or `cv2` imports fail
   (even if `.deps-installed` exists).
3. **Incomplete model cache** — re-downloads Hugging Face models when no
   `.onnx` files are present under `%LOCALAPPDATA%\cs-xray-ai\model_cache`.
4. **Ultralytics required** — listed in `requirements.txt` so clinic
   `caries/weights/best.pt` loads.
5. **PA/bitewing Training tab HTTP 404** — service now exposes `/pabw/dataset`,
   `/pabw/train`, `/pabw/train/status`, `/pabw/feedback`, and
   `pabw_feedback` on `/health` (same clinic caries flywheel as `best.pt`).

## Install

Double-click **`INSTALL.bat`** (preferred), or `setup-xray-ai-clinic-pc.bat`.

Verify with **`VERIFY-HEALTH.bat`**.
