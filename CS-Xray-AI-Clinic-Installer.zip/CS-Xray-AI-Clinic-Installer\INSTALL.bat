@echo off
REM ====================================================================
REM  CS X-ray Assist — ONE-CLICK clinic installer (fixed pack)
REM
REM  Includes:
REM    - Clinic caries weights (caries/weights/best.pt)
REM    - /pabw/* training API (PA/bitewing Training tab)
REM    - Self-repairing venv (onnxruntime / transformers / ultralytics)
REM    - Model-cache repair when ONNX files are missing
REM    - csxrayai:// protocol for the web app ▶ Server button
REM ====================================================================
setlocal EnableExtensions
cd /d "%~dp0"

echo.
echo ============================================
echo   CS X-ray Assist  -  Clinic Installer
echo ============================================
echo.
echo   Pack folder : %CD%
echo.

if not exist "%~dp0xray-ai-service\main.py" (
    echo [ERROR] xray-ai-service\main.py not found.
    echo         This installer must sit next to xray-ai-service\.
    pause
    exit /b 1
)
if not exist "%~dp0xray-ai-service\caries\weights\best.pt" (
    echo [ERROR] Clinic model missing:
    echo         xray-ai-service\caries\weights\best.pt
    pause
    exit /b 1
)
if not exist "%~dp0start-xray-ai.bat" (
    echo [ERROR] start-xray-ai.bat not found.
    pause
    exit /b 1
)

REM ---- Python check -------------------------------------------------
set "PY_CMD="
where python >nul 2>&1 && set "PY_CMD=python"
if not defined PY_CMD (
    where py >nul 2>&1 && set "PY_CMD=py"
)
if not defined PY_CMD (
    echo [ERROR] Python 3.10+ was not found on PATH.
    echo Install from https://www.python.org/downloads/
    echo IMPORTANT: tick "Add python.exe to PATH".
    pause
    exit /b 1
)
echo [1/4] Python OK: %PY_CMD%
%PY_CMD% --version

echo [2/4] Registering browser protocol csxrayai:// ...
call "%~dp0register-xray-ai-protocol.bat" nopause
if errorlevel 1 (
    echo [WARN] Protocol registration failed — you can still use start-xray-ai.bat.
)

echo [3/4] Starting AI service ^(first run installs deps + models^)...
echo       A console window will stay open — leave it running.
start "CS X-ray AI" "%~dp0start-xray-ai.bat"

echo [4/4] Waiting for health + PA/bitewing training API...
set "OK_HEALTH=0"
set "OK_PABW=0"
for /L %%I in (1,1,45) do (
    powershell -NoProfile -Command ^
      "try { $h=Invoke-RestMethod 'http://127.0.0.1:8877/health' -TimeoutSec 2; if ($h.ok) { exit 0 } else { exit 1 } } catch { exit 1 }" >nul 2>&1
    if not errorlevel 1 (
        set "OK_HEALTH=1"
        goto :health_done
    )
    timeout /t 2 /nobreak >nul
)
:health_done

if "%OK_HEALTH%"=="1" (
    powershell -NoProfile -Command ^
      "try { $r=Invoke-WebRequest 'http://127.0.0.1:8877/pabw/dataset' -UseBasicParsing -TimeoutSec 5; if ($r.StatusCode -eq 200) { exit 0 } else { exit 1 } } catch { exit 1 }" >nul 2>&1
    if not errorlevel 1 set "OK_PABW=1"
)

echo.
echo ============================================
if "%OK_HEALTH%"=="1" (
    echo   Health        : OK  http://127.0.0.1:8877/health
) else (
    echo   Health        : WAITING / FAILED
    echo   Check the "CS X-ray AI" console for errors.
)
if "%OK_PABW%"=="1" (
    echo   PA/BW train   : OK  /pabw/dataset
) else (
    echo   PA/BW train   : not ready yet — retry VERIFY-HEALTH.bat
)
echo.
echo   In Banana / clinic app:
echo     open an X-ray -^> Analyze
echo     Training -^> Periapical / bitewing tab should load
echo ============================================
echo.
echo Tip: later starts = double-click start-xray-ai.bat
echo      or use ▶ Server in the lightbox.
echo.
pause
endlocal
