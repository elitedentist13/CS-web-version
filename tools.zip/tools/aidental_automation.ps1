# Woodpecker Ai-Dental — search patient + fill "Create Patient" dialog
param(
    [Parameter(Mandatory = $true)][string]$PatientB64,
    [Parameter(Mandatory = $false)][string]$SummaryB64 = ''
)

$ErrorActionPreference = 'SilentlyContinue'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes

Add-Type @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;

public class AiDentalWin32 {
    public delegate bool EnumProc(IntPtr hWnd, IntPtr lParam);
    [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc lpEnumFunc, IntPtr lParam);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    public static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);

    public static List<IntPtr> VisibleWindowsForPid(int pid) {
        var list = new List<IntPtr>();
        EnumWindows((h, l) => {
            uint p;
            GetWindowThreadProcessId(h, out p);
            if (p == (uint)pid && IsWindowVisible(h)) list.Add(h);
            return true;
        }, IntPtr.Zero);
        return list;
    }

    public static string WindowTitle(IntPtr hWnd) {
        var sb = new StringBuilder(512);
        GetWindowText(hWnd, sb, sb.Capacity);
        return sb.ToString();
    }
}
'@

$payloadJson = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($PatientB64))
$p = $payloadJson | ConvertFrom-Json
$result = @{
    search_pasted = $false
    new_patient_prepared = $false
    aidental_running = $false
    fields_filled = @()
    debug = @()
}

function Log([string]$Msg) {
    if ($result.debug.Count -lt 14) { $result.debug += $Msg }
}

function Test-AiDentalProcess($proc) {
    return (
        $proc.ProcessName -like '*Ai-Dental*' -or
        $proc.ProcessName -like '*AiDental*' -or
        $proc.ProcessName -like '*Woodpecker*' -or
        $proc.MainWindowTitle -like '*Ai-Dental*' -or
        $proc.MainWindowTitle -like '*Ai Dental*' -or
        $proc.MainWindowTitle -like '*Woodpecker*' -or
        $proc.MainWindowTitle -like '*啄木鸟*'
    )
}

$ws = New-Object -ComObject WScript.Shell
$targetPid = $null
$targetTitle = ''
$targetHwnd = [IntPtr]::Zero

function Find-AiDentalProcess {
    return Get-Process | Where-Object {
        $_.MainWindowHandle -ne 0 -and (Test-AiDentalProcess $_)
    } | Sort-Object StartTime -Descending | Select-Object -First 1
}

function Attach-AiDentalProcess {
    param([int]$WaitSeconds = 8)
    $script:targetPid = $null
    $script:targetTitle = ''
    $script:targetHwnd = [IntPtr]::Zero
    $loops = [Math]::Max(1, $WaitSeconds * 2)
    for ($i = 0; $i -lt $loops; $i++) {
        $hit = Find-AiDentalProcess
        if ($hit) {
            $script:targetPid = $hit.Id
            $script:targetTitle = [string]$hit.MainWindowTitle
            $script:targetHwnd = [IntPtr]$hit.MainWindowHandle
            $null = $ws.AppActivate($targetPid)
            if (-not $ws.AppActivate($targetPid) -and $targetTitle) {
                $null = $ws.AppActivate($targetTitle)
            }
            return $true
        }
        Start-Sleep -Milliseconds 500
    }
    return $false
}

$attachWait = if ($p.mode -eq 'fill') { 45 } else { 8 }
if (-not (Attach-AiDentalProcess -WaitSeconds $attachWait)) {
    Log 'window-not-found'
    $result | ConvertTo-Json -Compress
    exit 2
}

$result.aidental_running = $true
Start-Sleep -Milliseconds 800
Log ('pid=' + $targetPid + ' title=' + $targetTitle)

function ReFocus {
    if ($targetPid -and $ws.AppActivate($targetPid)) { return $true }
    if ($targetTitle -and $ws.AppActivate($targetTitle)) { return $true }
    return $false
}

function Get-Root {
    param([IntPtr]$Hwnd = [IntPtr]::Zero)
    if ($Hwnd -ne [IntPtr]::Zero) {
        return [System.Windows.Automation.AutomationElement]::FromHandle($Hwnd)
    }
    return [System.Windows.Automation.AutomationElement]::FromHandle($targetHwnd)
}

function Get-ElementText($el) {
    if (-not $el) { return '' }
    $parts = @(
        [string]$el.Current.Name,
        [string]$el.Current.HelpText,
        [string]$el.Current.AutomationId
    )
    try {
        $leg = $el.GetCurrentPattern([System.Windows.Automation.LegacyIAccessiblePattern]::Pattern)
        if ($leg) { $parts += [string]$leg.Current.Name }
    } catch {}
    return ($parts -join ' ').Trim()
}

function Try-InvokeElement($el) {
    if (-not $el -or -not $el.Current.IsEnabled) { return $false }
    try {
        $inv = $el.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern)
        if ($inv) { $inv.Invoke(); return $true }
    } catch {}
    return $false
}

function Invoke-ByKeywords {
    param($Root, [string[]]$Keywords)
    if (-not $Root) { return $false }
    $types = @(
        [System.Windows.Automation.ControlType]::Button,
        [System.Windows.Automation.ControlType]::MenuItem,
        [System.Windows.Automation.ControlType]::Hyperlink,
        [System.Windows.Automation.ControlType]::SplitButton,
        [System.Windows.Automation.ControlType]::ListItem,
        [System.Windows.Automation.ControlType]::Image
    )
    foreach ($t in $types) {
        $cond = New-Object System.Windows.Automation.PropertyCondition(
            [System.Windows.Automation.AutomationElement]::ControlTypeProperty, $t)
        $items = $Root.FindAll([System.Windows.Automation.TreeScope]::Descendants, $cond)
        foreach ($el in $items) {
            $text = (Get-ElementText $el).ToLower()
            foreach ($kw in $Keywords) {
                $k = $kw.ToLower()
                if ($text -and ($text -like "*$k*")) {
                    if (Try-InvokeElement $el) {
                        Log ('invoked:' + (Get-ElementText $el))
                        return $true
                    }
                }
            }
        }
    }
    return $false
}

function Find-CreatePatientHwnd {
    foreach ($hwnd in [AiDentalWin32]::VisibleWindowsForPid([int]$targetPid)) {
        $title = [AiDentalWin32]::WindowTitle($hwnd)
        if ($title -match 'Create Patient|创建患者|新建患者|新增患者|Create') {
            Log ('create-hwnd:' + $title)
            return $hwnd
        }
    }
    $root = Get-Root
    $cond = [System.Windows.Automation.Condition]::TrueCondition
    $nodes = $root.FindAll([System.Windows.Automation.TreeScope]::Descendants, $cond)
    foreach ($node in $nodes) {
        $name = [string]$node.Current.Name
        if ($name -eq 'Create Patient' -or $name -match '^Create Patient') {
            Log 'create-pane-found'
            return $targetHwnd
        }
    }
    return [IntPtr]::Zero
}

function Find-CreatePatientRoot {
    $hwnd = Find-CreatePatientHwnd
    if ($hwnd -ne [IntPtr]::Zero) { return Get-Root $hwnd }
    $root = Get-Root
    $cond = [System.Windows.Automation.Condition]::TrueCondition
    $nodes = $root.FindAll([System.Windows.Automation.TreeScope]::Descendants, $cond)
    foreach ($node in $nodes) {
        $name = [string]$node.Current.Name
        if ($name -eq 'Create Patient') { return $node }
    }
    return $root
}

function Try-OpenCreatePatient {
    $existing = Find-CreatePatientHwnd
    if ($existing -ne [IntPtr]::Zero) {
        Log 'create-already-open'
        return $existing
    }

    ReFocus | Out-Null
    $mainRoot = Get-Root

    # Patient tab is usually default; try Create Patient toolbar / list actions
    $openKeywords = @(
        'Create Patient', 'create patient', 'New Patient', 'new patient',
        'Add Patient', 'add patient', '新增患者', '新建患者', '创建患者',
        '新增', '新建', '添加', 'Create', 'Add', 'New', '+'
    )
    Invoke-ByKeywords $mainRoot $openKeywords | Out-Null
    Start-Sleep -Milliseconds 1600

    $hwnd = Find-CreatePatientHwnd
    if ($hwnd -ne [IntPtr]::Zero) { return $hwnd }

    ReFocus | Out-Null
    $ws.SendKeys('^n')
    Start-Sleep -Milliseconds 1200
    $hwnd = Find-CreatePatientHwnd
    if ($hwnd -ne [IntPtr]::Zero) { return $hwnd }

    ReFocus | Out-Null
    $ws.SendKeys('{INSERT}')
    Start-Sleep -Milliseconds 1200
    return Find-CreatePatientHwnd
}

function Find-Edits($Root) {
    if (-not $Root) { return @() }
    $editType = [System.Windows.Automation.ControlType]::Edit
    $cond = New-Object System.Windows.Automation.PropertyCondition(
        [System.Windows.Automation.AutomationElement]::ControlTypeProperty, $editType)
    return @($Root.FindAll([System.Windows.Automation.TreeScope]::Descendants, $cond))
}

function Try-SetValue($Element, [string]$Value) {
    if (-not $Element -or -not $Value) { return $false }
    try {
        $vp = $Element.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern)
        if ($vp) { $vp.SetValue($Value); return $true }
    } catch {}
    return $false
}

function Paste-IntoFocused([string]$Value) {
    if (-not $Value) { return $false }
    [System.Windows.Forms.Clipboard]::SetText($Value)
    Start-Sleep -Milliseconds 100
    $ws.SendKeys('^a')
    Start-Sleep -Milliseconds 80
    $ws.SendKeys('^v')
    Start-Sleep -Milliseconds 180
    return $true
}

function Find-EditByExactLabel {
    param($Root, [string]$Label)
    $textType = [System.Windows.Automation.ControlType]::Text
    $condText = New-Object System.Windows.Automation.PropertyCondition(
        [System.Windows.Automation.AutomationElement]::ControlTypeProperty, $textType)
    $texts = $Root.FindAll([System.Windows.Automation.TreeScope]::Descendants, $condText)
    foreach ($text in $texts) {
        $nm = ([string]$text.Current.Name).Trim()
        if ($nm -ne $Label -and $nm -ne ($Label + '*')) { continue }
        try {
            $walker = $text
            for ($d = 0; $d -lt 6; $d++) {
                $parent = $walker.GetCurrentParent()
                if (-not $parent) { break }
                $editType = [System.Windows.Automation.ControlType]::Edit
                $condEdit = New-Object System.Windows.Automation.PropertyCondition(
                    [System.Windows.Automation.AutomationElement]::ControlTypeProperty, $editType)
                $edits = $parent.FindAll([System.Windows.Automation.TreeScope]::Descendants, $condEdit)
                foreach ($edit in $edits) {
                    if ($edit.Current.IsEnabled) { return $edit }
                }
                $walker = $parent
            }
        } catch {}
    }
    return $null
}

function Find-EditByLabelKeywords {
    param($Root, [string[]]$Keywords)
    $textType = [System.Windows.Automation.ControlType]::Text
    $condText = New-Object System.Windows.Automation.PropertyCondition(
        [System.Windows.Automation.AutomationElement]::ControlTypeProperty, $textType)
    $texts = $Root.FindAll([System.Windows.Automation.TreeScope]::Descendants, $condText)
    foreach ($text in $texts) {
        $nm = ([string]$text.Current.Name).Trim().ToLower()
        foreach ($kw in $Keywords) {
            if ($nm -eq $kw.ToLower() -or $nm -like ($kw.ToLower() + '*')) {
                try {
                    $parent = $text.GetCurrentParent()
                    for ($d = 0; $d -lt 5; $d++) {
                        if (-not $parent) { break }
                        $editType = [System.Windows.Automation.ControlType]::Edit
                        $condEdit = New-Object System.Windows.Automation.PropertyCondition(
                            [System.Windows.Automation.AutomationElement]::ControlTypeProperty, $editType)
                        $edits = $parent.FindAll([System.Windows.Automation.TreeScope]::Descendants, $condEdit)
                        foreach ($edit in $edits) {
                            if ($edit.Current.IsEnabled) { return $edit }
                        }
                        $parent = $parent.GetCurrentParent()
                    }
                } catch {}
            }
        }
    }
    return $null
}

function Set-WoodpeckerGender {
    param($Root, [string]$Sex)
    if (-not $Sex) { return $false }
    $sexUp = $Sex.Trim().ToUpper()
    $want = ''
    if ($sexUp -in @('F', 'FEMALE', '女')) { $want = 'Female' }
    elseif ($sexUp -in @('M', 'MALE', '男')) { $want = 'Male' }
    if (-not $want) { return $false }

    $radioType = [System.Windows.Automation.ControlType]::RadioButton
    $cond = New-Object System.Windows.Automation.PropertyCondition(
        [System.Windows.Automation.AutomationElement]::ControlTypeProperty, $radioType)
    $radios = $Root.FindAll([System.Windows.Automation.TreeScope]::Descendants, $cond)
    foreach ($radio in $radios) {
        $name = [string]$radio.Current.Name
        if ($name -ne $want) { continue }
        try {
            $sel = $radio.GetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern)
            if ($sel) { $sel.Select(); return $true }
        } catch {}
        try {
            $inv = $radio.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern)
            if ($inv) { $inv.Invoke(); return $true }
        } catch {}
        try { $radio.SetFocus(); $ws.SendKeys(' '); return $true } catch {}
    }
    return $false
}

function Fill-WoodpeckerCreatePatient {
    param([IntPtr]$FormHwnd = [IntPtr]::Zero)
    $root = if ($FormHwnd -ne [IntPtr]::Zero) { Get-Root $FormHwnd } else { Find-CreatePatientRoot }
    if (-not $root) { return $false }

    if ($FormHwnd -ne [IntPtr]::Zero) {
        $title = [AiDentalWin32]::WindowTitle($FormHwnd)
        if ($title) { $null = $ws.AppActivate($title) }
        Start-Sleep -Milliseconds 350
    } else {
        ReFocus | Out-Null
    }

    $englishName = [string]$p.patient_name
    if (-not $englishName) { $englishName = [string]$p.chinese_name }
    $dob = [string]$p.dob
    $sex = [string]$p.sex
    $chartNo = [string]$p.patient_no

    $filled = $false

    # --- Name* (English) ---
    if ($englishName) {
        $nameEdit = Find-EditByExactLabel $root 'Name'
        if (-not $nameEdit) { $nameEdit = Find-EditByLabelKeywords $root @('Name') }
        if ($nameEdit) {
            try { $nameEdit.SetFocus() } catch {}
            if (Try-SetValue $nameEdit $englishName) {
                $result.fields_filled += 'patient_name'
                $filled = $true
                Log ('name=' + $englishName)
            } elseif (Paste-IntoFocused $englishName) {
                $result.fields_filled += 'patient_name'
                $filled = $true
                Log ('name-paste=' + $englishName)
            }
        }
    }

    # --- Gender* (Male / Female radio) ---
    if ($sex) {
        if (Set-WoodpeckerGender $root $sex) {
            $result.fields_filled += 'sex'
            $filled = $true
            Log ('gender=' + $sex)
        }
    }

    # --- Birthday* ---
    if ($dob) {
        $bdayEdit = Find-EditByExactLabel $root 'Birthday'
        if (-not $bdayEdit) { $bdayEdit = Find-EditByLabelKeywords $root @('Birthday', 'Birth') }
        if ($bdayEdit) {
            try { $bdayEdit.SetFocus() } catch {}
            if (Try-SetValue $bdayEdit $dob) {
                $result.fields_filled += 'dob'
                $filled = $true
                Log ('dob=' + $dob)
            } elseif (Paste-IntoFocused $dob) {
                $result.fields_filled += 'dob'
                $filled = $true
                Log ('dob-paste=' + $dob)
            }
        }
    }

    # --- Chart No. (patient no., optional) ---
    if ($chartNo) {
        $chartEdit = Find-EditByExactLabel $root 'Chart No.'
        if (-not $chartEdit) { $chartEdit = Find-EditByLabelKeywords $root @('Chart No', 'Chart') }
        if ($chartEdit) {
            if (Try-SetValue $chartEdit $chartNo) {
                $result.fields_filled += 'patient_no'
                Log ('chart=' + $chartNo)
            }
        }
    }

    # Fallback: Woodpecker tab order after Doctor combo — Name, then Gender, then Birthday
    if ($result.fields_filled.Count -lt 2) {
        $edits = @(Find-Edits $root | Where-Object { $_.Current.IsEnabled })
        $formEdits = @()
        foreach ($e in $edits) {
            $n = ([string]$e.Current.Name).ToLower()
            if ($n -match 'doctor|remark|address|email|tel|cell|fax|country|state|city|area|history|age|surname|search') { continue }
            $formEdits += $e
        }
        if ($formEdits.Count -ge 2) {
            # Often: [0]=doctor combo area skipped, find first wide edit for Name
            $nameCandidate = $formEdits | Where-Object {
                $_.Current.BoundingRectangle.Width -gt 120
            } | Select-Object -First 1
            if ($nameCandidate -and $englishName) {
                try { $nameCandidate.SetFocus() } catch {}
                if (Paste-IntoFocused $englishName) {
                    $result.fields_filled += 'patient_name'
                    $filled = $true
                }
            }
            if ($sex -and ($result.fields_filled -notcontains 'sex')) {
                Set-WoodpeckerGender $root $sex | Out-Null
                if ($result.fields_filled -notcontains 'sex') { $result.fields_filled += 'sex'; $filled = $true }
            }
            if ($dob -and ($result.fields_filled -notcontains 'dob')) {
                $bdayCandidate = $formEdits | Where-Object {
                    [string]$_.Current.Name -match 'birth|date' -or
                    ([string]$_.Current.Value -match '^\d{4}-\d{2}-\d{2}$')
                } | Select-Object -First 1
                if (-not $bdayCandidate -and $formEdits.Count -ge 2) {
                    $bdayCandidate = $formEdits | Select-Object -Skip 1 -First 1
                }
                if ($bdayCandidate) {
                    try { $bdayCandidate.SetFocus() } catch {}
                    if (Paste-IntoFocused $dob) {
                        $result.fields_filled += 'dob'
                        $filled = $true
                    }
                }
            }
        }
    }

    return $filled
}

function Try-SearchPatient([string]$Text) {
    if (-not $Text) { return $false }
    ReFocus | Out-Null
    $root = Get-Root
    foreach ($edit in (Find-Edits $root)) {
        if (-not $edit.Current.IsEnabled) { continue }
        $name = [string]$edit.Current.Name
        if ($name -match '搜|search|filter|query|查找|chart') { continue }
        if (Try-SetValue $edit $Text) {
            $ws.SendKeys('{ENTER}')
            return $true
        }
    }
    return $false
}

# --- Main workflow ---
if ($p.mode -eq 'fill') {
    # Clinic workflow: Woodpecker already open → user clicks Create Patient → we fill fields.
    # Wait up to 60s for the Create Patient dialog (user may click it after confirming in the web app).
    $createHwnd = [IntPtr]::Zero
    for ($i = 0; $i -lt 120; $i++) {
        Attach-AiDentalProcess -WaitSeconds 1 | Out-Null
        $createHwnd = Find-CreatePatientHwnd
        if ($createHwnd -ne [IntPtr]::Zero) {
            Log 'create-patient-ready'
            break
        }
        Start-Sleep -Milliseconds 500
    }
    if ($createHwnd -ne [IntPtr]::Zero) {
        if (Fill-WoodpeckerCreatePatient -FormHwnd $createHwnd) {
            $result.new_patient_prepared = $true
            Log 'woodpecker-filled'
        } else {
            Log 'create-open-no-fill'
        }
    } else {
        Log 'create-not-opened'
    }
} elseif ($p.mode -ne 'search') {
    $createHwnd = Try-OpenCreatePatient
    if ($createHwnd -ne [IntPtr]::Zero) {
        Start-Sleep -Milliseconds 700
        if (Fill-WoodpeckerCreatePatient -FormHwnd $createHwnd) {
            $result.new_patient_prepared = $true
            Log 'woodpecker-filled'
        } else {
            Log 'create-open-no-fill'
        }
    } elseif (Fill-WoodpeckerCreatePatient) {
        $result.new_patient_prepared = $true
        Log 'woodpecker-filled-manual'
    } else {
        Log 'create-not-opened'
    }
}

if ($p.mode -eq 'auto' -or $p.mode -eq 'search') {
    if (Try-SearchPatient ([string]$p.search_text)) {
        $result.search_pasted = $true
        Log 'search-ok'
    }
}

if ($SummaryB64) {
    try {
        $summaryText = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($SummaryB64))
        if ($summaryText) { [System.Windows.Forms.Clipboard]::SetText($summaryText) }
    } catch {}
}

$result | ConvertTo-Json -Compress
exit 0
