@echo off
setlocal
cd /d "%~dp0"
title Joyful Smile X-Ray Launcher

echo.
echo  Joyful Smile - X-Ray Desktop Bridge
echo  (Ai-Dental, Carestream, NNT/NEWTOM)
echo.

where python >nul 2>&1
if %ERRORLEVEL%==0 (
    python "%~dp0xray_launcher.py"
    goto :done
)

where py >nul 2>&1
if %ERRORLEVEL%==0 (
    py -3 "%~dp0xray_launcher.py"
    goto :done
)

echo Python 3 is required. Install from https://www.python.org/downloads/
echo Then run this batch file again.
pause
exit /b 1

:done
echo.
pause
