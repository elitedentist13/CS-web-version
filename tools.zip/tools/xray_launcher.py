#!/usr/bin/env python3
"""
Joyful Smile — local desktop bridge for X-ray software (port 17890).

Used by the web app (Consultation → X-rays → Ai-Dental / Carestream / NNT).
Browsers cannot start .exe files or paste into desktop apps; this helper does.
"""

from __future__ import annotations

import base64
import json
import os
import platform
import socket
import subprocess
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Callable
from urllib.parse import parse_qs, urlparse

PORT = 17890

# Candidate install paths (first match wins). Override via ?app_path= from the web app.
SYSTEM_CANDIDATES = {
    "carestream": [
        r"C:\Program Files (x86)\Carestream\Patient Browser\Patient.exe",
        r"C:\Program Files\Carestream\Patient Browser\Patient.exe",
        r"C:\Users\Public\Desktop\CS Imaging Software.lnk",
    ],
    "aidental": [
        r"C:\Ai-Dental\Ai-Dental-Client\Ai-Dental.exe",
        r"C:\Ai-Dental\Ai-Dental-Client\Ai-Dental-Client.exe",
        r"C:\Ai-Dental\Ai-Dental.exe",
        r"C:\Program Files\Ai-Dental\Ai-Dental-Client\Ai-Dental.exe",
        r"C:\Program Files (x86)\Ai-Dental\Ai-Dental-Client\Ai-Dental.exe",
        r"C:\Program Files\Ai-Dental\Ai-Dental.exe",
        r"C:\Users\Public\Desktop\Ai-Dental-Client.lnk",
        r"C:\Users\Public\Desktop\Ai-Dental.lnk",
    ],
    "nntnewtom": [
        r"C:\NNT\NNT.exe",
        r"C:\Program Files\NNT\NNT.exe",
        r"C:\Users\Public\Desktop\NNT.lnk",
        r"C:\Users\Public\Desktop\NEWTOM.lnk",
    ],
}

OPEN_KEYS = frozenset(SYSTEM_CANDIDATES.keys())

CREATE_NO_WINDOW = 0x08000000


def is_file(path: str) -> bool:
    return bool(path) and os.path.isfile(path)


def resolve_app_path(key: str, override: str = "") -> str:
    override = (override or "").strip()
    if is_file(override):
        return override
    for candidate in SYSTEM_CANDIDATES.get(key, []):
        if is_file(candidate):
            return candidate
    return override


def system_exists(key: str) -> bool:
    return bool(resolve_app_path(key))


def ensure_folder(path: str) -> None:
    path = (path or "").strip()
    if not path:
        return
    try:
        os.makedirs(path, exist_ok=True)
    except OSError:
        pass


def launch_windows(path: str) -> bool:
    if not is_file(path):
        return False
    try:
        os.startfile(path)  # noqa: S606 — intentional desktop bridge on Windows
        return True
    except OSError:
        pass
    try:
        subprocess.Popen([path], shell=False)
        return True
    except OSError:
        return False


def build_patient_record(q: Callable[[str], str]) -> dict[str, str]:
    """Demographics from the web app active patient / X-ray tab."""
    phone = q("phone") or q("mobile_phone")
    return {
        "patient_id": q("patient_id"),
        "patient_no": q("patient_no"),
        "patient_name": q("patient_name"),
        "chinese_name": q("chinese_name"),
        "dob": q("dob"),
        "sex": q("sex"),
        "hkid": q("hkid"),
        "phone": phone,
        "email": q("email"),
        "address": q("address"),
    }


def normalize_sex_for_aidental(sex: str) -> str:
    """Return value suitable for Woodpecker Male/Female radios (F/M also accepted)."""
    s = (sex or "").strip().upper()
    if s in ("F", "FEMALE", "女"):
        return "F"
    if s in ("M", "MALE", "男"):
        return "M"
    return (sex or "").strip()


def patient_clipboard_summary(patient: dict[str, str]) -> str:
    lines: list[str] = []
    if patient.get("patient_no"):
        lines.append("Patient No: " + patient["patient_no"])
    if patient.get("chinese_name"):
        lines.append("Chinese Name: " + patient["chinese_name"])
    if patient.get("patient_name"):
        lines.append("Name: " + patient["patient_name"])
    if patient.get("dob"):
        lines.append("DOB: " + patient["dob"])
    sex = normalize_sex_for_aidental(patient.get("sex", ""))
    if sex:
        lines.append("Sex: " + sex)
    if patient.get("hkid"):
        lines.append("ID: " + patient["hkid"])
    if patient.get("phone"):
        lines.append("Phone: " + patient["phone"])
    return "\n".join(lines)


def build_search_text(q: Callable[[str], str], system_key: str) -> str:
    explicit = q("search_text")
    if explicit:
        return explicit
    patient_no = q("patient_no")
    chinese_name = q("chinese_name")
    patient_name = q("patient_name")
    if system_key == "aidental":
        return patient_no or chinese_name or patient_name or ""
    if patient_name and patient_no:
        return f"{patient_name} ({patient_no})"
    return patient_name or patient_no or ""


def set_clipboard_text(text: str) -> bool:
    if not text:
        return False
    try:
        import ctypes
        CF_UNICODETEXT = 13
        GMEM_MOVEABLE = 0x0002
        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32

        data = text.encode("utf-16-le") + b"\x00\x00"
        handle = kernel32.GlobalAlloc(GMEM_MOVEABLE, len(data))
        if not handle:
            return False
        locked = kernel32.GlobalLock(handle)
        if not locked:
            kernel32.GlobalFree(handle)
            return False
        ctypes.memmove(locked, data, len(data))
        kernel32.GlobalUnlock(handle)
        if not user32.OpenClipboard(None):
            kernel32.GlobalFree(handle)
            return False
        user32.EmptyClipboard()
        user32.SetClipboardData(CF_UNICODETEXT, handle)
        user32.CloseClipboard()
        return True
    except Exception:
        return False


def run_powershell(script: str, timeout: int = 60) -> tuple[int, str]:
    encoded = base64.b64encode(script.encode("utf-16-le")).decode("ascii")
    try:
        proc = subprocess.run(
            [
                "powershell",
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-EncodedCommand",
                encoded,
            ],
            capture_output=True,
            creationflags=CREATE_NO_WINDOW,
            timeout=timeout,
        )
        stdout = (proc.stdout or b"").decode("utf-8", errors="replace").strip()
        return int(proc.returncode or 0), stdout
    except Exception:
        return 1, ""


def _aidental_search_variants(search_text: str) -> list[str]:
    """Try common patient-no formats Ai-Dental may expect."""
    base = (search_text or "").strip()
    if not base:
        return []
    variants: list[str] = []
    for val in (base, base.lstrip("0") or base):
        if val and val not in variants:
            variants.append(val)
    digits = "".join(ch for ch in base if ch.isdigit())
    if digits:
        for val in (digits, digits.lstrip("0") or digits):
            if val and val not in variants:
                variants.append(val)
    return variants


def _aidental_script_path() -> str:
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "aidental_automation.ps1")


def run_aidental_automation(patient_b64: str, summary_b64: str) -> tuple[int, str]:
    script_path = _aidental_script_path()
    if not is_file(script_path):
        return 1, ""
    try:
        proc = subprocess.run(
            [
                "powershell",
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
                script_path,
                "-PatientB64",
                patient_b64,
                "-SummaryB64",
                summary_b64,
            ],
            capture_output=True,
            creationflags=CREATE_NO_WINDOW,
            timeout=90,
        )
        stdout = (proc.stdout or b"").decode("utf-8", errors="replace").strip()
        stderr = (proc.stderr or b"").decode("utf-8", errors="replace").strip()
        if stderr:
            sys.stderr.write("[aidental-automation] " + stderr + "\n")
        return int(proc.returncode or 0), stdout
    except Exception as exc:
        sys.stderr.write("[aidental-automation] " + str(exc) + "\n")
        return 1, ""


def automate_aidental_patient_workflow(
    patient: dict[str, str], mode: str = "auto"
) -> dict[str, object]:
    """
    Search existing patient in Ai-Dental; if mode allows, open new-patient form
    and pre-fill demographics from the web app (no auto-save — user confirms).
    """
    result: dict[str, object] = {
        "search_pasted": False,
        "new_patient_prepared": False,
        "fields_filled": [],
        "clipboard_summary": patient_clipboard_summary(patient),
    }
    search_text = (
        patient.get("patient_no")
        or patient.get("chinese_name")
        or patient.get("patient_name")
        or ""
    ).strip()
    if not search_text and mode != "new":
        return result

    summary = patient_clipboard_summary(patient)
    if summary:
        set_clipboard_text(summary)

    sex_val = normalize_sex_for_aidental(patient.get("sex", ""))
    english_name = (patient.get("patient_name") or "").strip()
    if not english_name:
        english_name = (patient.get("chinese_name") or "").strip()
    payload = {
        "mode": mode,
        "search_text": search_text,
        "patient_no": patient.get("patient_no", ""),
        "patient_name": english_name,
        "chinese_name": patient.get("chinese_name", ""),
        "dob": patient.get("dob", ""),
        "sex": sex_val,
        "hkid": patient.get("hkid", ""),
        "phone": patient.get("phone", ""),
    }
    patient_b64 = base64.b64encode(
        json.dumps(payload, ensure_ascii=False).encode("utf-8")
    ).decode("ascii")

    summary_b64 = base64.b64encode(
        summary.encode("utf-8") if summary else b""
    ).decode("ascii")

    code, stdout = run_aidental_automation(patient_b64, summary_b64)
    if stdout:
        try:
            ps_result = json.loads(stdout.splitlines()[-1])
            if isinstance(ps_result, dict):
                result.update(ps_result)
                if isinstance(result.get("fields_filled"), list):
                    result["fields_filled"] = [
                        str(x) for x in result["fields_filled"]
                    ]
                debug = ps_result.get("debug")
                if isinstance(debug, list):
                    for line in debug:
                        sys.stderr.write("[aidental-automation] %s\n" % line)
        except json.JSONDecodeError:
            pass
    if code == 0 and not result.get("search_pasted") and search_text:
        for attempt_text in _aidental_search_variants(search_text):
            if automate_aidental_patient_search_only(attempt_text):
                result["search_pasted"] = True
                break
    return result


def automate_aidental_patient_search_only(search_text: str) -> bool:
    """Legacy search-only fallback."""
    if not search_text:
        return False
    set_clipboard_text(search_text)
    for attempt_text in _aidental_search_variants(search_text):
        safe_text = attempt_text.replace("'", "''")
        script = f"""
$ErrorActionPreference = 'SilentlyContinue'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
$ws = New-Object -ComObject WScript.Shell
$targetPid = $null
$targetHwnd = [IntPtr]::Zero
for ($i = 0; $i -lt 40; $i++) {{
    $hit = Get-Process | Where-Object {{
        $_.MainWindowHandle -ne 0 -and (
            $_.ProcessName -like '*Ai-Dental*' -or $_.ProcessName -like '*AiDental*'
        )
    }} | Sort-Object StartTime -Descending | Select-Object -First 1
    if ($hit) {{
        $targetPid = $hit.Id
        $targetHwnd = [IntPtr]$hit.MainWindowHandle
        if ($ws.AppActivate($targetPid)) {{ break }}
    }}
    Start-Sleep -Milliseconds 400
}}
if ($targetHwnd -eq [IntPtr]::Zero) {{ exit 2 }}
Start-Sleep -Milliseconds 800
[System.Windows.Forms.Clipboard]::SetText('{safe_text}')
$root = [System.Windows.Automation.AutomationElement]::FromHandle($targetHwnd)
$editType = [System.Windows.Automation.ControlType]::Edit
$cond = New-Object System.Windows.Automation.PropertyCondition(
    [System.Windows.Automation.AutomationElement]::ControlTypeProperty, $editType)
$edits = $root.FindAll([System.Windows.Automation.TreeScope]::Descendants, $cond)
foreach ($edit in $edits) {{
    if (-not $edit.Current.IsEnabled) {{ continue }}
    try {{
        $vp = $edit.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern)
        if ($vp) {{
            $vp.SetValue('{safe_text}')
            $ws.SendKeys('{{ENTER}}')
            exit 0
        }}
    }} catch {{}}
}}
exit 1
"""
        code, _ = run_powershell(script, timeout=45)
        if code == 0:
            return True
    return False


def automate_aidental_patient_search(search_text: str) -> bool:
    """Backward-compatible search helper."""
    return automate_aidental_patient_workflow(
        {"patient_no": search_text}, mode="search"
    ).get("search_pasted") is True


def fill_aidental_create_patient(
    patient: dict[str, str] | None,
    search_text: str = "",
) -> dict[str, object]:
    """Attach to running Woodpecker/Ai-Dental and fill open Create Patient dialog."""
    record = dict(patient or {})
    if search_text and not record.get("patient_no"):
        record["patient_no"] = search_text
    automation = automate_aidental_patient_workflow(record, mode="fill")
    if not automation.get("new_patient_prepared"):
        sys.stderr.write(
            "[xray-launcher] Ai-Dental fill-only incomplete for patient_no=%s debug=%s\n"
            % (
                record.get("patient_no", search_text),
                automation.get("debug", []),
            )
        )
    return automation


def launch_with_optional_search(
    key: str,
    app_path: str,
    folder_path: str,
    search_text: str,
    patient: dict[str, str] | None = None,
    mode: str = "auto",
) -> tuple[bool, dict[str, object]]:
    ensure_folder(folder_path)
    automation: dict[str, object] = {
        "search_pasted": False,
        "new_patient_prepared": False,
        "aidental_running": False,
        "fields_filled": [],
    }
    if key == "aidental" and mode == "fill":
        automation = fill_aidental_create_patient(patient, search_text)
        running = bool(automation.get("aidental_running"))
        return running, automation

    launched = launch_windows(app_path)
    if launched and key == "aidental":
        record = dict(patient or {})
        if search_text and not record.get("patient_no"):
            record["patient_no"] = search_text
        automation = automate_aidental_patient_workflow(record, mode=mode)
        if not automation.get("search_pasted") and not automation.get(
            "new_patient_prepared"
        ):
            sys.stderr.write(
                "[xray-launcher] Ai-Dental automation incomplete for patient_no=%s\n"
                % record.get("patient_no", search_text)
            )
    return launched, automation


def cors_send(handler: BaseHTTPRequestHandler) -> None:
    handler.send_header("Access-Control-Allow-Origin", "*")
    handler.send_header("Access-Control-Allow-Methods", "GET, OPTIONS")
    handler.send_header("Access-Control-Allow-Headers", "*")


class XrayLauncherHandler(BaseHTTPRequestHandler):
    server_version = "JoyfulXrayLauncher/1.6"

    def log_message(self, fmt: str, *args) -> None:
        try:
            sys.stderr.write("[xray-launcher] " + (fmt % args) + "\n")
        except Exception:
            pass

    def do_OPTIONS(self) -> None:
        self.send_response(204)
        cors_send(self)
        self.end_headers()

    def _send_json(self, code: int, payload: dict) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        cors_send(self)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        route = (parsed.path or "/").rstrip("/") or "/"
        qs = parse_qs(parsed.query, keep_blank_values=True)

        def q(name: str) -> str:
            vals = qs.get(name, [""])
            return (vals[0] if vals else "").strip()

        if route == "/status":
            self._send_json(
                200,
                {
                    "ok": True,
                    "carestream_exists": system_exists("carestream"),
                    "aidental_exists": system_exists("aidental"),
                    "nntnewtom_exists": system_exists("nntnewtom"),
                },
            )
            return

        if route == "/workstation":
            host = (platform.node() or socket.gethostname() or "PC").strip()
            self._send_json(200, {"ok": True, "computer": host})
            return

        if route.startswith("/open/"):
            key = route.split("/open/", 1)[1].split("/")[0].strip().lower()
            if key not in OPEN_KEYS:
                self._send_json(400, {"ok": False, "error": "unknown_system"})
                return

            app_path = resolve_app_path(key, q("app_path"))
            if not app_path:
                self._send_json(404, {"ok": False, "error": "app_not_found", "system": key})
                return

            if platform.system() != "Windows":
                self._send_json(501, {"ok": False, "error": "windows_only"})
                return

            search_text = build_search_text(q, key)
            patient_record = build_patient_record(q)
            aidental_mode = (q("aidental_mode") or "auto").lower()
            if aidental_mode not in ("auto", "search", "new", "fill"):
                aidental_mode = "auto"
            if key == "aidental":
                aidental_mode = "fill"
            launched, automation = launch_with_optional_search(
                key,
                app_path,
                q("folder_path"),
                search_text,
                patient=patient_record,
                mode=aidental_mode if key == "aidental" else "search",
            )
            fill_only = key == "aidental" and aidental_mode == "fill"
            running = bool(automation.get("aidental_running"))
            filled = bool(automation.get("new_patient_prepared"))
            ok = running if fill_only else launched
            self._send_json(
                200 if ok else (404 if fill_only else 500),
                {
                    "ok": ok and (filled if fill_only else True),
                    "system": key,
                    "app": app_path,
                    "fill_only": fill_only,
                    "aidental_running": running,
                    "patient_no": patient_record.get("patient_no", ""),
                    "patient_name": patient_record.get("patient_name", ""),
                    "chinese_name": patient_record.get("chinese_name", ""),
                    "dob": patient_record.get("dob", ""),
                    "sex": patient_record.get("sex", ""),
                    "hkid": patient_record.get("hkid", ""),
                    "search_text": search_text,
                    "search_pasted": bool(
                        launched and automation.get("search_pasted")
                    ),
                    "new_patient_prepared": filled,
                    "fields_filled": automation.get("fields_filled") or [],
                    "debug": automation.get("debug") or [],
                    "clipboard_summary": automation.get("clipboard_summary") or "",
                    "error": (
                        None
                        if ok
                        else ("aidental_not_running" if fill_only else "launch_failed")
                    ),
                },
            )
            return

        self._send_json(404, {"ok": False, "error": "not_found"})


def main() -> None:
    if platform.system() != "Windows":
        print("X-Ray Launcher supports Windows only.")
        sys.exit(1)

    httpd = HTTPServer(("127.0.0.1", PORT), XrayLauncherHandler)
    print("Joyful Smile X-Ray Launcher")
    print("Listening on http://127.0.0.1:%d" % PORT)
    print("Carestream found:", system_exists("carestream"))
    print("Ai-Dental found: ", system_exists("aidental"))
    print("NNT/NEWTOM found:", system_exists("nntnewtom"))
    print("Ai-Dental: fill-only — open Woodpecker manually, click Create Patient, then Ai-Dental in the web app.")
    print("Leave this window open while using Consultation -> X-rays.")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")


if __name__ == "__main__":
    main()
