@echo off
REM Quick check that the local AI service matches the fixed clinic pack.
setlocal
echo.
echo Checking http://127.0.0.1:8877 ...
echo.
powershell -NoProfile -Command ^
  "$ErrorActionPreference='Stop';" ^
  "try {" ^
  "  $h = Invoke-RestMethod 'http://127.0.0.1:8877/health' -TimeoutSec 5;" ^
  "  Write-Host ('ok={0} ready={1}' -f $h.ok, $h.ready);" ^
  "  Write-Host ('tooth={0} condition={1} caries={2}' -f $h.models.tooth_detector.ready, $h.models.condition_detector.ready, $h.models.caries_model.ready);" ^
  "  Write-Host ('caries_feedback={0} pabw_feedback={1}' -f $h.caries_feedback.enabled, $h.pabw_feedback.enabled);" ^
  "  if ($h.models.caries_model.weights) { Write-Host ('weights={0}' -f $h.models.caries_model.weights) }" ^
  "  $d = Invoke-WebRequest 'http://127.0.0.1:8877/pabw/dataset' -UseBasicParsing -TimeoutSec 8;" ^
  "  Write-Host ('pabw/dataset HTTP {0}' -f $d.StatusCode);" ^
  "  $c = Invoke-WebRequest 'http://127.0.0.1:8877/caries/dataset' -UseBasicParsing -TimeoutSec 8;" ^
  "  Write-Host ('caries/dataset HTTP {0}' -f $c.StatusCode);" ^
  "  if ($h.ok -and $h.pabw_feedback.enabled -and $d.StatusCode -eq 200) { Write-Host ''; Write-Host 'PASS — clinic pack looks healthy.'; exit 0 }" ^
  "  Write-Host ''; Write-Host 'FAIL — service responded but incomplete.'; exit 2" ^
  "} catch {" ^
  "  Write-Host ('FAIL — ' + $_.Exception.Message);" ^
  "  Write-Host 'Start the service with INSTALL.bat or start-xray-ai.bat first.';" ^
  "  exit 1" ^
  "}"
echo.
pause
endlocal
